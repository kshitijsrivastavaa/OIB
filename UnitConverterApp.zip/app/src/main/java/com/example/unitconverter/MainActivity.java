
package com.example.unitconverter;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText inputValue;
    private Spinner fromUnit, toUnit;
    private Button convertButton;
    private TextView result;

    String[] units = {"Centimeters", "Meters", "Grams", "Kilograms"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inputValue = findViewById(R.id.inputValue);
        fromUnit = findViewById(R.id.fromUnit);
        toUnit = findViewById(R.id.toUnit);
        convertButton = findViewById(R.id.convertButton);
        result = findViewById(R.id.result);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, units);
        fromUnit.setAdapter(adapter);
        toUnit.setAdapter(adapter);

        convertButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double value = Double.parseDouble(inputValue.getText().toString());
                String from = fromUnit.getSelectedItem().toString();
                String to = toUnit.getSelectedItem().toString();
                double convertedValue = convert(value, from, to);
                result.setText("Result: " + convertedValue + " " + to);
            }
        });
    }

    private double convert(double value, String from, String to) {
        // Convert input to a base unit (meters for length, kilograms for weight)
        double baseValue = value;

        // Convert from chosen unit to base unit
        switch (from) {
            case "Centimeters":
                baseValue = value / 100; // cm to meters
                break;
            case "Meters":
                baseValue = value;
                break;
            case "Grams":
                baseValue = value / 1000; // grams to kilograms
                break;
            case "Kilograms":
                baseValue = value;
                break;
        }

        // Convert from base unit to desired unit
        switch (to) {
            case "Centimeters":
                return baseValue * 100;
            case "Meters":
                return baseValue;
            case "Grams":
                return baseValue * 1000;
            case "Kilograms":
                return baseValue;
        }
        return value;
    }
}
